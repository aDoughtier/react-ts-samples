import React, { ReactElement, ReactNode, lazy } from 'react'

export interface RouteType {
  index?:any
  path?: string
  //TODO:element类型判断
  element: React.LazyExoticComponent<(props:any) => any>;
  children?: RouteType[]
  text?: string
}

const routeData: RouteType[] = [
  {
    path: '/',
    element: lazy(()=>import("@/pages/Layout")),
    children: [
      {
        path: '/game',
        element: lazy(() => import("@/pages/Game")),
        text:"教程：井字棋"
      },
      {
        path: '/ts-useContext',
        element: lazy(() => import("@/pages/TSUseContext")),
        text:"安装-使用TypeScript"
      }
    ]
  }
]

export default routeData